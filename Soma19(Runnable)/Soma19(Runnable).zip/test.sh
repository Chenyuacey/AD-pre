CUDA_VISIBLE_DEVICES=0 /usr/local/anaconda3/envs/pytorch040/bin/python tools/infer_simple.py



