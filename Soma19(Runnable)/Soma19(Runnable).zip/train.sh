CUDA_VISIBLE_DEVICES=0 /usr/local/anaconda3/envs/pytorch040/bin/python tools/train_net_step.py --dataset soma \
--cfg configs/soma_starting/e2e_mask_rcnn_soma_dsn_body.yaml --bs 2 --use_tfboard



